#! /usr/bin/R
source("/media/HQ/FG_16S/SourceTracker/sourcetracker-1.0.1/src/SourceTracker.r")
load(file="/media/HQ/EMP_data/model_new/Train_dataset/st_empo3.RData")
load("ds5.RData")

pred_list_5<-list()
proptab_list_5<-list()

for (i in 1:3)
{
	st_predic1<- predict(st_empo3,ds[1,], alpha1=0.001, alpha2=0.2)
	st_predic2 <- as.data.frame(st_predic1[[2]])
	pred_list_5[[i]]<-st_predic1
	proptab_list_5[[i]]<-st_predic2
}

save(pred_list_5,file="pred_list_5_a2_2.RData")
save(proptab_list_5,file="proptab_list_5_a2_2.RData")


q()
